#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QtNetwork/QTcpSocket>
#include <sys/types.h>
#include <QThread>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();


private slots:
    void on_pushButton_clicked();
    void sleep(int msec);
     void readClient();
    void reconnect();
    void on_pushButton_clicked(bool checked);
    void tip();
    void on_sendBtn_clicked();

    void on_connectBtn_clicked();
    void keyPressEvent(QKeyEvent * event);

private:
    Ui::MainWindow *ui;
     QTcpSocket *client;
     QAbstractSocket::SocketError socketError ;

};

#endif // MAINWINDOW_H
