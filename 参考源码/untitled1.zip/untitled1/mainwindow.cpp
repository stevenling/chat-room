#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "QTime"
//using namspace std;
#include <QDateTime>
#include <QtDebug>
#include <QTimer>
#include <QKeyEvent>
#include<QEvent>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->sendBtn->setFocus();
    ui->sendContent->setWindowOpacity(0.2);
  //  ui->textBrowser->setText("hh");
        client = new QTcpSocket(this);
        client->connectToHost("192.168.137.5", 4000);
        connect(client, SIGNAL(readyRead()), this, SLOT(readClient()));
        connect(client,SIGNAL(error(QAbstractSocket::SocketError)),this,SLOT(tip()) );

}

void MainWindow::tip(){
    ui->connectBtn->setText("连接服务器失败");
    ui->sendBtn->setDisabled(true);
}


void MainWindow::sleep(int msec)//自定义Qt延时函数,单位毫秒

{

    QDateTime last = QDateTime::currentDateTime();

    QDateTime now;

    while (1)

    {

        now = QDateTime::currentDateTime();

        if (last.msecsTo(now) >= msec)

        {

            break;

        }

    }

}

MainWindow::~MainWindow()
{
    delete ui;
}
//void acceptConnection()
//{
//    clientConnection = server->nextPendingConnection();
//    connect(clientConnection, SIGNAL(readyRead()), this, SLOT(readClient()));
//}
void MainWindow::readClient()
{
 //   QString str = client->readAll();
    //或者
    char buf[1024];
    client->read(buf,1024);
    QString str = QString::fromLocal8Bit(buf);
    if(strcmp(buf,"%&@(") == 0) {
        reconnect();
    }else if(strcmp(buf,"~12oLH>")==0){
       ui->connectBtn->setText("等待对方接入！");
       ui->sendBtn->setDisabled(true);
    }else if(strcmp(buf,"#3206*")==0){
        ui->connectBtn->setText("已成功建立连接！");
        ui->sendBtn->setEnabled(true);
    }else{
        ui->textBrowser->append(" ");
        ui->textBrowser->setAlignment(Qt::AlignLeft);

        ui->textBrowser->append(str);
    }
}
void MainWindow::on_pushButton_clicked()
{
    //cout<<"test"<<endl;

    int i=4;
    char buff[1024];
    char *data="hello qt!";

}

void MainWindow::on_pushButton_clicked(bool checked)
{
   // on_pushButton_clicked();
}

void MainWindow::on_sendBtn_clicked()
{
    int a[100];
        QString str = ui->sendContent->toPlainText();
        int len = str.length();
        qDebug("readString = %s",qPrintable(str));
    //qDebug<<a;
        QByteArray datasend = str.toLocal8Bit();
        client->write(datasend);

         ui->textBrowser->append(" ");
         ui->textBrowser->setAlignment(Qt::AlignRight);
         ui->textBrowser->append(str);
         ui->sendContent->clear();
         ui->sendContent->setFocus();

     //    ui->textBrowser->set
//        QQuickView *label = new label();
//        ui->textBrowser->createWindowContainer();
}
void MainWindow::keyPressEvent(QKeyEvent *event)
{
    if (event->key() == Qt::Key_Return)
        on_sendBtn_clicked();
}
void MainWindow::reconnect(){
    client->close();
    client = new QTcpSocket(this);
    client->connectToHost("192.168.137.5", 4000);
    connect(client, SIGNAL(readyRead()), this, SLOT(readClient()));
}

void MainWindow::on_connectBtn_clicked()
{
    //client->close();
    reconnect();
}
