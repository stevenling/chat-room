#include "mainwindow.h"
#include <QApplication>
#include <pthread.h>
#include <sys/types.h>
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.show();

//    ui->textBrowser->setText("hh");
//    client = new QTcpSocket(this);
//    client->connectToHost("192.168.137.5", 4000);
//    QTimer *timer = new QTimer(this);
//    for(;;)
//    if(client->bytesAvailable()>0){
//         QByteArray datagram;
//         qDebug()<<"enter in smarthomeserver and receive data!";
//         datagram.resize(client->bytesAvailable());
//         client->read(datagram.data(),datagram.size());
//         QString msg=datagram;
//         ui->textBrowser->append( msg);

//    }else{
//        ui->textBrowser->append("22");

//    }

    return a.exec();
}
